# AutomationFramework
A Sample Test Automation Framework

This project contains a sample Hybrid Automation Framework.
It can be used in Java Based Projects to automate TestCases written in TestNG and Appium.
