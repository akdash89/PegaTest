package com.pega.automationframework.util.common;

import java.util.Map;

import org.openqa.selenium.By;

import com.pega.automationframework.TestRunner;
import com.pega.automationframework.exception.AutomationFrameworkException;
import com.pega.automationframework.exception.KeywordNotFoundException; class KeyWordTool {

	public static By getLocator(String testCaseName, String locatorName) throws AutomationFrameworkException {

		Map<String, String> keywordMap = TestRunner.keywordDetails.get(testCaseName);
		String keyWordValue = keywordMap.get(locatorName);
		if (keyWordValue == null) {
			throw new KeywordNotFoundException(locatorName);
		}

		if (keyWordValue.startsWith("id")) {
			return By.id(keyWordValue.substring(keyWordValue.indexOf(':') + 1));
		}

		if (keyWordValue.startsWith("className")) {
			return By.className(keyWordValue.substring(keyWordValue.indexOf(':') + 1));
		}

		throw new AutomationFrameworkException("Keyword Type Unknown [" + keyWordValue + "]");
	}

}
