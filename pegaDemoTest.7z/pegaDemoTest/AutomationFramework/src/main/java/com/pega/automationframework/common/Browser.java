package com.pega.automationframework.common;

public class Browser {

    public static final String FIREFOX = "FIREFOX";
    public static final String CHROME = "CHROME";
    public static final String IE = "IE";

}
