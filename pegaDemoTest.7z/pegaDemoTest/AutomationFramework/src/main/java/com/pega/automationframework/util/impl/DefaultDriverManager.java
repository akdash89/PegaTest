package com.pega.automationframework.util.impl;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.pega.automationframework.common.Browser;
import com.pega.automationframework.exception.AutomationFrameworkException;
import com.pega.automationframework.util.DriverManager;
import com.pega.automationframework.util.common.ConfigReader;
public class DefaultDriverManager implements DriverManager 
{
	private static String sPropFileName = "config.properties";

    @Override
    public WebDriver getDriver() throws AutomationFrameworkException {

	// create a Web Driver and return it to the client
	String browser = ConfigReader.getProperty("config.properties", "BROWSER");
	WebDriver driver = null;

	if (browser.equals(Browser.FIREFOX)) {
	    driver = new FirefoxDriver();

	} else if (browser.equals(Browser.CHROME)) {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Resources\\chromedriver.exe");
	    driver = new ChromeDriver();

	} else if (browser.equals(Browser.IE)) {
	    driver = new InternetExplorerDriver();

	} else {
	    throw new AutomationFrameworkException("Browser [" + browser + "] Not Supported");
	}

	return driver;
    }
    

}
