package com.pega.automationframework.exception;

public class AutomationFrameworkException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -858646296313600367L;

    public AutomationFrameworkException() {
	// TODO Auto-generated constructor stub
    }

    public AutomationFrameworkException(String message) {
	super(message);
	// TODO Auto-generated constructor stub
    }

    public AutomationFrameworkException(Throwable cause) {
	super(cause);
	// TODO Auto-generated constructor stub
    }

    public AutomationFrameworkException(String message, Throwable cause) {
	super(message, cause);
	// TODO Auto-generated constructor stub
    }

    public AutomationFrameworkException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
	super(message, cause, enableSuppression, writableStackTrace);
	// TODO Auto-generated constructor stub
    }

}
