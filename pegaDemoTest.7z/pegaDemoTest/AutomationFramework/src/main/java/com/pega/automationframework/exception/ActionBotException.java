package com.pega.automationframework.exception;

import org.openqa.selenium.StaleElementReferenceException;

public class ActionBotException extends Exception
{
	private static final long serialVersionUID = 2564228321992099502L;

	public ActionBotException(String message) 
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ActionBotException(String string, StaleElementReferenceException e) 
	{
		// TODO Auto-generated constructor stub
	}
	public ActionBotException(String string, Exception e)
	{
		// TODO Auto-generated constructor stub
	}
	
	

}
