package com.pega.automationframework.common;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ScreenShotListner implements ITestListener
{
public static Map<String, RemoteWebDriver> driversMap = new HashMap<String, RemoteWebDriver>();
	
	@Override
	public void onTestFailure(ITestResult result) 
	{

		String testName = result.getMethod().getMethodName();
		// getting the date
		SimpleDateFormat sdfDate = new SimpleDateFormat("dd_MM_yyyy");// dd/MM/yyyy
		Date now = new Date();
		String strDate = sdfDate.format(now);
		System.out.println(driversMap.get(testName));
		EventFiringWebDriver eDriver = new EventFiringWebDriver(driversMap.get(testName));
		File srcFile = eDriver.getScreenshotAs(OutputType.FILE);
		File theDirc = new File(System.getProperty("user.dir") + "//Screenshot//fail//"+strDate);
		if (!theDirc.exists()) 
		{
		    //System.out.println("creating directory: " + theDir.getName());
		    

		    try{
		        theDirc.mkdir();
		        FileUtils.copyFile(srcFile,new File(theDirc+ File.separator+testName + strDate + ".png"));
		    } 
		    catch (IOException e)
		    {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		
		}
		else
		{
			 try{
			        
			       FileUtils.copyFile(srcFile,new File(theDirc+ File.separator+testName + strDate + ".png"));
			    } 
			    catch (IOException e)
			    {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
			
		 }

	   }

	@Override
	public void onFinish(ITestContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestSkipped(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestStart(ITestResult arg0) 
	{
	

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		
		String testName = result.getMethod().getMethodName();
		// getting the date
		SimpleDateFormat sdfDate = new SimpleDateFormat("dd_MM_yyyy");// dd/MM/yyyy
		Date now = new Date();
		String strDate = sdfDate.format(now);
		
		
		
		System.out.println(driversMap.get(testName));
		EventFiringWebDriver eDriver = new EventFiringWebDriver(driversMap.get(testName));
		File srcFile = eDriver.getScreenshotAs(OutputType.FILE);
		File theDir = new File(System.getProperty("user.dir") + "//Screenshot//pass//"+strDate);
		if (!theDir.exists()) 
		{
		    //System.out.println("creating directory: " + theDir.getName());
		    boolean sign = false;

		    try{
		        theDir.mkdir();
		        FileUtils.copyFile(srcFile,new File(theDir+ File.separator+testName + strDate + ".png"));
		    } 
		    catch (IOException e)
		    {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		
		}
		else
		{
			 try{
			        
			       FileUtils.copyFile(srcFile,new File(theDir+ File.separator+testName + strDate + ".png"));
			    } 
			    catch (IOException e)
			    {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
			
		}
		
	
	}
		/*try {
			// it will save screen shot on test case name and date
			//FileUtils.copyFile(srcFile,new File(System.getProperty("user.dir") + "//Screenshot//pass//" + testName + strDate + ".png"));
		} catch (IOException e) {

			e.printStackTrace();
		}*/

	}

