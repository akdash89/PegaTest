package com.pega.automationframework.util;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import com.pega.automationframework.exception.AutomationFrameworkException;
import io.appium.java_client.AppiumDriver;

public interface DriverManager {

    public WebDriver getDriver() throws AutomationFrameworkException;

}
